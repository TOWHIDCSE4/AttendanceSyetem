<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeeInformation extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee_information', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('phone_number',50);
            $table->string('residence_number',50);
            $table->string('passport_number',50);
            $table->string('pit_code');
            $table->string('gender');
            $table->date('join_date');
            $table->date('job_quit_date');
            $table->string('designation');
            $table->string('si_code');
            $table->date('birthday');
            $table->string('nationality');

            $table->string('country_name_1');
            $table->string('province_name_1');
            $table->string('city_name_1');
            $table->string('house_number_1');
            $table->string('postal_code_1');

            $table->string('country_name_2');
            $table->string('province_name_2');
            $table->string('city_name_2');
            $table->string('house_number_2');
            $table->string('postal_code_2');

            $table->string('employee_id');
            $table->foreign('employee_id')->references('id')->on('employee');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee_information');
    }
}
