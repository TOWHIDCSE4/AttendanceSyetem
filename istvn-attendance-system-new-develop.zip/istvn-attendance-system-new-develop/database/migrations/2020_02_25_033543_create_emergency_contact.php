<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmergencyContact extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('emergency_contact', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('email_address',50);
            $table->string('first_name',50);
            $table->string('last_name',50);
            $table->string('relationship',50);
            $table->string('phone_number',50);

            $table->string('country_name_1');
            $table->string('province_name_1');
            $table->string('city_name_1');
            $table->string('house_number_1');
            $table->string('postal_code_1');

            $table->string('employee_id');
            $table->foreign('employee_id')->references('id')->on('employee');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('emergency_contact');
    }
}
