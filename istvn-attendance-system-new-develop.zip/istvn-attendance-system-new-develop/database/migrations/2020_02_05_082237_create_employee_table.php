<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmployeeTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('employee', function (Blueprint $table) {
//            $table->bigIncrements('id');
            $table->string('id',50);
            $table->primary('id');
            $table->string('email_address',50);
            $table->string('first_name',50);
            $table->string('last_name',50);
            $table->string('employee_type',50);

            $table->bigInteger('role_id')->unsigned();
            $table->foreign('role_id')->references('id')->on('role');

            $table->bigInteger('dept_id')->unsigned();
            $table->foreign('dept_id')->references('id')->on('department');

            $table->bigInteger('sec_id')->unsigned();
            $table->foreign('sec_id')->references('id')->on('section');

            $table->bigInteger('employee_status_id')->unsigned();
            $table->foreign('employee_status_id')->references('id')->on('employee_status');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('employee');
    }
}
