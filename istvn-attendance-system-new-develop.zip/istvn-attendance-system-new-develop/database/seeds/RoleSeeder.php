<?php

use App\Models\Role;
use Illuminate\Database\Seeder;

class RoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
//        Role::create([
//            'role_name_key'=>'super_admin',
//            'display_name'=>'Super Admin'
//        ]);
        Role::create([
            'role_name_key'=>'manager',
            'display_name'=>'Manager'
        ]);
        Role::create([
            'role_name_key'=>'member',
            'display_name'=>'Member'
        ]);
    }
}
