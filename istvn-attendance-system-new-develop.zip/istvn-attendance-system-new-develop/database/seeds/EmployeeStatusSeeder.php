<?php

use Illuminate\Database\Seeder;
use App\Models\EmployeeStatus;

class EmployeeStatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        EmployeeStatus::create([
            'status_name'=>'inactive'
        ]);
        EmployeeStatus::create([
            'status_name'=>'active'
        ]);
        EmployeeStatus::create([
            'status_name'=>'inLongVacation'
        ]);
        EmployeeStatus::create([
            'status_name'=>'inMaternityLeave'
        ]);
    }
}
