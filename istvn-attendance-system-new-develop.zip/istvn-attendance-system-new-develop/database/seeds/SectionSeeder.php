<?php

use Illuminate\Database\Seeder;
use App\Models\Section;

class SectionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Section::create([
            'section_name' => 'section_1',
            'department_id' => '1'
        ]);
        Section::create([
            'section_name' => 'section_2',
            'department_id' => '2'
        ]);
    }
}
