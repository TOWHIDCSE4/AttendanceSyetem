<?php

use Illuminate\Database\Seeder;
use App\Models\LoginInformation;
use Illuminate\Support\Facades\Hash;
class LoginInfoSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        LoginInformation::create([
            'employee_id'=>'user_test_1',
            'password'=>Hash::make('123456')
        ]);
        LoginInformation::create([
            'employee_id'=>'user_test_2',
            'password'=>Hash::make('123456')
        ]);

    }
}
