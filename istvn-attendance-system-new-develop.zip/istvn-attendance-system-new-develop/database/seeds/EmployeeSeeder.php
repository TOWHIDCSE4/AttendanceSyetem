<?php

use App\Models\Employee;
use Illuminate\Database\Seeder;

class EmployeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Employee::create([
            'id'=>'user_test_1',
            'email_address'=>'phanbinh29081997@gmail.com',
            'first_name'=>'Bin',
            'last_name'=>'Fan',
            'employee_type'=>'full_time',
            'role_id'=>'1',
            'dept_id'=>'1',
            'sec_id'=>'2',
            'employee_status_id'=>'1'
        ]);
        Employee::create([
            'id'=>'user_test_2',
            'email_address'=>'test1@gmail.com',
            'first_name'=>'test',
            'last_name'=>'test',
            'employee_type'=>'part_time',
            'role_id'=>'2',
            'dept_id'=>'2',
            'sec_id'=>'1',
            'employee_status_id'=>'2'
        ]);

    }
}
