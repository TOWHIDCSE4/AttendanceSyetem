<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Section extends Model
{
    //
    protected $table = 'section';
    protected $fillable = ['id','section_name','department_id'];
    protected $primaryKey = 'id';
    public $timestamps = true;

    public function department()
    {
        return $this->belongsTo('App\Models\Department');
    }
}
