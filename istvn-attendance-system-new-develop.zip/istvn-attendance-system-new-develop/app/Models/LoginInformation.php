<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Model;

class LoginInformation extends Model
{
    //
    protected $table = 'login_information';
    protected $primaryKey = 'id';
    protected $fillable = ['id','employee_id','password','created_at','updated_at'];
    public $timestamps = true;
}
