<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmergencyContact extends Model
{
    //
    protected $table = 'emergency_contact';
    protected $primaryKey = 'id';
    protected $fillable = ['id','email_address','first_name','last_name','relationship','phone_number','country_name_1',
        'province_name_1','city_name_1','house_number_1','postal_code_1','employee_id','created_at','updated_at'];
    public $timestamps = true;

    public function employee()
    {
        return $this->hasOne('App\Models\Employee','employee_id');
    }
}
