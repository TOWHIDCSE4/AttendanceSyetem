<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmployeeInformation extends Model
{
    //
    protected $table = 'employee_information';
    protected $primaryKey = 'id';
    protected $fillable = ['id','phone_number','residence_number','passport_number','pit_code','gender','join_date',
        'job_quit_date','designation','si_code','birthday','nationality','country_name_1','province_name_1',
        'city_name_1','house_number_1','postal_code_1','country_name_2','province_name_2',
        'city_name_2','house_number_2','postal_code_2','employee_id','created_at','updated_at'];
    public $timestamps = true;
}
