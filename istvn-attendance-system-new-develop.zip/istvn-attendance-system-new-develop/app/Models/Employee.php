<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Employee extends Model
{
    //
    protected $table = 'employee';
    protected $casts = ['id' => 'string'];
    protected $fillable = ['id','email_address','first_name','last_name','employee_type','role_id','dept_id',
        'sec_id','employee_status_id','created_at','updated_at'];
    public $incrementing = false;
    public $timestamps = true;

    public function role()
    {
        return $this->belongsTo('App\Models\Role');
    }
    public function department()
    {
        return $this->belongsTo('App\Models\Department', "dept_id");
    }
    public function section()
    {
        return $this->belongsTo('App\Models\Section', 'sec_id');
    }
    public function employeeStatus()
    {
        return $this->belongsTo('App\Models\EmployeeStatus', 'employee_status_id');
    }
    public function emergencyContact()
    {
        return $this->hasOne('App\Models\EmergencyContact');
    }
}
