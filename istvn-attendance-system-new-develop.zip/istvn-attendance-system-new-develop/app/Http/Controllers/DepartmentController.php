<?php

namespace App\Http\Controllers;

use App\Models\Employee;
use App\Models\Section;
use Illuminate\Http\Request;
use Illuminate\Http\DB;
use App\Models\Department;

class DepartmentController extends Controller
{
    /**
     *
     * @return \Illuminate\Http\Response department list
     */
    public function index()
    {

        $departments = Department::all();
        return view('department/index', compact('departments'));
    }

    /**
     * Store a newly created resource in Department storage.
     *
     * @param  \Illuminate\Http\Request  $request  department_name
     * @return \Illuminate\Http\Response Department is successfully saved
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'department_name' => 'required|max:255',
        ]);
        Department::create($validatedData);
        return redirect(route('departments.index'))->with('success', 'Department is successfully saved');
    }

    /**
     * Display the specified resource department list.
     *
     * @param  int  $id department_id
     * @return \Illuminate\Http\Response show department list
     */
    public function show($id)
    {
        $department = Department::findOrFail($id);
        $sections = $department->sections;
        return view('department/show', compact('department', 'sections'));
    }

    /**
     * Update the specified resource in  department updated storage.
     *
     * @param  \Illuminate\Http\Request  $request department_name
     * @param  int  $id department_id
     * @return \Illuminate\Http\Response department is successfully updated
     */
    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'department_name' => 'required|max:255',
           ]);

        Department::whereId($id)->update($validatedData);
        return redirect('departments')->with('success', 'department is successfully updated');
    }

    /**
     * Remove the specified resource from  Department deleted storage.
     *
     * @param  int  $id department id
     * @return \Illuminate\Http\Response Department is successfully deleted
     */
    public function destroy($id)
    {

        Section::where('department_id', '=', $id)->delete();
        Department::whereId($id)->delete();

        return redirect('departments')->with('success', 'Department is successfully deleted');
    }
}
