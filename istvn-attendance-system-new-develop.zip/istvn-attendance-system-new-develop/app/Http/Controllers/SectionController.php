<?php

namespace App\Http\Controllers;

use App\Models\Section;
use Illuminate\Http\Request;
use Illuminate\Http\DB;
use App\Models\Department;

class SectionController extends Controller
{


    /**
     *  Section Store a newly created resource in storage.
     * @param  int  id  department_id
     * @param  \Illuminate\Http\Request  $request  section_name department_id
     * @return \Illuminate\Http\Response Section is successfully saved
     */
    public function store(Request $request)
    {
        $id = $request->get('department_id');
        $validatedData = ([
            'section_name' => $request->get('section_name'),
            'department_id' => $id
            ]);
        Section::create($validatedData);
        return redirect(route('departments.show', $id))->with('success', 'Section is successfully saved');
    }


    /**
     * Section Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request department_id section_name
     * @param  int  $id $section_id
     * @return \Illuminate\Http\Response Section is successfully updated
     */
    public function update(Request $request, $id)
    {
        $department_id = $request->get('department_id');
        $validatedData = $request->validate([ 'section_name' => 'required|max:255', ]);
        Section::whereId($id)->update($validatedData);
        return redirect(route('departments.show', $department_id))->with('success', 'Section is successfully updated');
    }

    /**
     *Section  Remove the specified resource from storage.
     * @param  \Illuminate\Http\Request  $request department_id section_name
     * @param  int  $id $section_id
     * @return \Illuminate\Http\Response Section is successfully deleted
     */
    public function destroy(Request $request, $id)
    {
        $department_id = $request->get('department_id');
        Section::whereId($id)->delete();
        return redirect(route('departments.show', $department_id))->with('success', 'Section is successfully deleted');
    }
}
