<?php

namespace App\Http\Controllers;

use App\Models\EmergencyContact;
use Illuminate\Http\Request;
use App\Models\Employee;

class EmergencyContactController extends Controller
{


    /**
     * @param  int  $id  Emergency contact id
     * @return \Illuminate\Http\Response SHOW emergency_contact create
     */
    public function create()
    {
        $id=1;
        return view('emergency_contact/create', compact('id'));
    }

    /**
     * emergency_contact Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request $emergencyContactData
     * @return \Illuminate\Http\Response Emergency contact basic information is successfully created
     */
    public function store(Request $request)
    {


        $emergencyContactData = ([
            'employee_id'=>1,
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'relationship' => $request->get('relationship'),
            'phone_number' => $request->get('phone_number'),
            'email_address' => $request->get('email_address'),
            'country_name_1' => $request->get('country_name_1'),
            'province_name_1' => $request->get('province_name_1'),
            'city_name_1' => $request->get('city_name_1'),
            'house_number_1' => $request->get('house_number_1'),
            'postal_code_1' => $request->get('postal_code_1')
        ]);
        EmergencyContact::create($emergencyContactData);
        return redirect('employees')->with('success', 'Emergency contact basic information is successfully created');
    }


    /**
     *
     * @param  int  $id EmergencyContact id
     * @return \Illuminate\Http\Response emergencyContact
     */
    public function edit($id)
    {
        $emergencyContact = EmergencyContact::where('employee_id', '=', $id)->select()->get();
        return view('emergency_contact/create', compact('id', 'emergencyContact'));
    }

    /**
     *
     * @param  \Illuminate\Http\Request  $request $emergencyContactData
     * @param  int  $id EmergencyContact id
     * @return \Illuminate\Http\Response Emergency contact basic information is successfully updated
     */
    public function update(Request $request, $id)
    {
        $emergencyContactId = $id;
        $emergencyContactData = ([
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'relationship' => $request->get('relationship'),
            'phone_number' => $request->get('phone_number'),
            'email_address' => $request->get('email_address'),
            'country_name_1' => $request->get('country_name_1'),
            'province_name_1' => $request->get('province_name_1'),
            'city_name_1' => $request->get('city_name_1'),
            'house_number_1' => $request->get('house_number_1'),
            'postal_code_1' => $request->get('postal_code_1')
        ]);
        EmergencyContact::whereId($emergencyContactId)->update($emergencyContactData);
        return redirect('employees')->with('success', 'Emergency contact basic information is successfully updated');
    }


}
