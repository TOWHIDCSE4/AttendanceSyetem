<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Models\Employee;
use App\Models\Role;
use App\Models\Section;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }



    /**
     * user Show the form for creating a new resource.
     * @param id int employee_id
     * @return \Illuminate\Http\Response user create show
     */
    public function create(Request $request)
    {
        //
        $id = $request->get('employee_id');
        $role = Role::all();
        return view('user/create', compact('role', 'id'));
    }

    /**
     * User Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request $data (user all data)
     * @return \Illuminate\Http\Response User is successfully created
     */
    public function store(Request $request)
    {
        //
        $data = ([
            'user_name' => $request->get('user_name'),
            'password' => Hash::make($request->get('password')),
            'active_status' => '1',
            'role_id' => $request->get('role_id')
        ]);
        $id = $request->get('id');
        $user = User::create($data)->id;
        Employee::whereId($id)->update(['user_id'=>$user]);
        return redirect('employees')->with('success', 'User is successfully created');
    }


    /**
     *
     * @param  int  $id user id
     * @return \Illuminate\Http\Response show user add data
     */
    public function edit($id)
    {
        //
        $user = User::findOrFail($id);
        $role = Role::all();
        return view('user/edit', compact(['user','role']));
    }

    /**
     * User Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request user $validatedData
     * @param  int  $id  user id
     * @return \Illuminate\Http\Response User is successfully updated
     */
    public function update(Request $request, $id)
    {
        //
        $password = $request->get('password');
        $validatedData = ([
            'user_name' => $request->get('user_name'),
            'role_id' => $request->get('role_id')
        ]);
        if ($password != '') {
            $validatedData = ([
                'user_name' => $request->get('user_name'),
                'role_id' => $request->get('role_id'),
                'password' => Hash::make($password)
            ]);
        }
        User::whereId($id)->update($validatedData);
        return redirect('employees')->with('success', 'User is successfully updated');
    }


}
