<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\Employee;
use App\Models\PasswordReset;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */
    use SendsPasswordResetEmails;
    /**
     * Send a reset link to the given user.
     * Send an email containing the link to reset the password
     * send email
     * @param  \Illuminate\Http\Request  $emailDB,$token
     * @return \Illuminate\Http\RedirectResponse
     *  The content of the email contained in the view layouts/forgot.blade.php
     */


    public function sendEmail($emailDB, $token)
    {
        Mail::send(
            'auth.passwords.mail-reset-link',
            [
                'user' => $emailDB,
                'token'=> $token
            ],
            function ($message) use ($emailDB) {
                $message->to($emailDB[0]->email_address);
                $message->subject('Reset password');
            }
        );
    }

    /**
     * Get the password reset credentials from the request.
     *function for sending reset link to the given email
     * @param  \Illuminate\Http\Request  $request
     * @return array  Call sendEmail function to send an email
     * insert data after send an email
     * return redirect  if email of this user id not match
     */

    public function sendResetLinkEmail(Request $request)
    {
        $gMail = $request->input('email');
        $token = $request->input('_token');
        $time = Carbon::now();
        $emailDB = Employee::where('email_address', '=', $gMail)->select('*')->get();
        if (count($emailDB) <= 0) {
            return redirect()->back()->with(['error' => 'Email does not exist']);
        }


        $this->sendEmail($emailDB, $token);
        PasswordReset::create(['email' => $gMail, 'token' => $token, 'created_at' => $time]);
        return redirect()->back()->with(['success' => 'We have e-mailed your password reset link!']);

    }


}
