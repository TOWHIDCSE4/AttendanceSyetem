<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\MessageBag;
use App\Models\Employee;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }


    /**
     * login
     * Send an email containing the link to reset the password
     * send email
     * @param  \Illuminate\Http\Request $request get data from login form
     * @return \Illuminate\Http\RedirectResponse check email and password correct or not
     * if email or password not match
     *  The content of the email contained in the view layouts/forgot.blade.php
     */


    public function login(Request $request)
    {

        $userID = $request->input('user_id');
        $password = $request->input('password');
        if (Auth::attempt(['employee_id' => $userID, 'password' => $password])) {
            $user = Employee::whereId($userID)->select('*')->get();
            Session::put('user_name', $user[0]->last_name);
            return redirect()->intended('home');
        }
        $errors = new MessageBag(['errorLogin' => 'Incorrect user name or password']);
        return redirect()->back()->withInput()->withErrors($errors);
    }
}
