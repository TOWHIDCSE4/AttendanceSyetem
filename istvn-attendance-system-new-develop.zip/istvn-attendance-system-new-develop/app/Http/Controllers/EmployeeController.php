<?php

namespace App\Http\Controllers;

use App\Models\EmployeeInformation;
use App\Models\LoginInformation;
use App\Models\Department;
use App\Models\Employee;
use App\Models\EmployeeStatus;
use App\Models\Role;
use App\Models\Section;
use App\Models\EmergencyContact;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class EmployeeController extends Controller
{
    public function __construct()
    {
//        $this->middleware('auth');
    }

    /**
     *
     * @return \Illuminate\Http\Response employees list show data
     */
    public function index()
    {
        //
        $employees = Employee::all();

        return view('employee/index', compact('employees'));
    }

    /**
     * employee create Store a newly created resource in storage.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $department = Department::all();
        $section = Section::all();
        $role = Role::all();
        $employeeStatus = EmployeeStatus::all();

        return view('employee/create', compact(['department', 'section', 'role', 'employeeStatus']));
    }

    /**
     * Store a newly created resource in Employee storage.
     *
     * @param \Illuminate\Http\Request $request $employeeData
     * @return \Illuminate\Http\Response Employee is successfully created
     */
    public function store(Request $request)
    {
        //
        $employeeData = ([
            'id' => $request->get('user_id'),
            'email_address' => $request->get('email_address'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'role_id' => $request->get('role_id'),
            'employee_type' => $request->get('employee_type'),
            'employee_status_id' => $request->get('employee_status_id'),
            'dept_id' => $request->get('dept_id'),
            'sec_id' => $request->get('sec_id')
        ]);
        $employeeId = Employee::create($employeeData)->id;

        $employeeInformationData = ([
            'phone_number' => $request->get('phone_number'),
            'residence_number' => $request->get('residence_number'),
            'passport_number' => $request->get('passport_number'),
            'gender' => $request->get('gender'),
            'join_date' => $request->get('join_date'),
            'job_quit_date' => $request->get('quit_date'),
            'designation' => $request->get('designation'),
            'si_code' => $request->get('si_code'),
            'pit_code' => $request->get('pit_code'),
            'birthday' => $request->get('birth_date'),
            'nationality' => $request->get('nationality'),
            'country_name_1' => $request->get('country_name_1'),
            'province_name_1' => $request->get('province_name_1'),
            'city_name_1' => $request->get('city_name_1'),
            'house_number_1' => $request->get('house_number_1'),
            'postal_code_1' => $request->get('postal_code_1'),
            'country_name_2' => $request->get('country_name_2'),
            'province_name_2' => $request->get('province_name_2'),
            'city_name_2' => $request->get('city_name_2'),
            'house_number_2' => $request->get('house_number_2'),
            'postal_code_2' => $request->get('postal_code_2'),
            'employee_id' => $request->get('user_id')
        ]);
        EmployeeInformation::create($employeeInformationData);

        $loginInformationData = ([
            'password' => bcrypt(value($request->get('password'))),
            'employee_id' => $request->get('user_id')
        ]);


        LoginInformation::create($loginInformationData);

        return redirect('employees')->with('success', 'Employee is successfully created');
    }


    /**
     * Show the form for editing the specified resource in employee update .
     *
     * @param int $id Employee id $employeeInformationid $loginInformationid
     * @return \Illuminate\Http\Response  employee update data show
     */
    public function edit($id)
    {
        $employee = Employee::findOrFail($id);
        $employeeInformation = EmployeeInformation::findOrFail($id);
        $loginInformation = LoginInformation::findOrFail($id);
        $role = Role::select()->get();
        $department = Department::select()->get();
        $section = Section::select()->get();
        $employeeStatus = EmployeeStatus::select()->get();
        return view('employee/create', compact(['employee', 'employeeInformation', 'loginInformation', 'role',
            'department', 'section', 'employeeStatus']));
    }

    /**
     * Update the specified resource in Employee updated storage.
     *
     * @param \Illuminate\Http\Request $request $employeeData
     * @param int $id $employeeId
     * @return \Illuminate\Http\Response  Employee is successfully updated
     */
    public function update(Request $request, $id)
    {
        //
        $employeeId = $id;
        $employeeData = ([
            'email_address' => $request->get('email_address'),
            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),
            'role_id' => $request->get('role_id'),
            'employee_type' => $request->get('employee_type'),
            'employee_status_id' => $request->get('employee_status_id'),
            'dept_id' => $request->get('dept_id'),
            'sec_id' => $request->get('sec_id')
        ]);
        Employee::whereId($id)->update($employeeData);

        $employeeInformationData = ([
            'phone_number' => $request->get('phone_number'),
            'residence_number' => $request->get('residence_number'),
            'passport_number' => $request->get('passport_number'),
            'gender' => $request->get('gender'),
            'join_date' => $request->get('join_date'),
            'job_quit_date' => $request->get('quit_date'),
            'designation' => $request->get('designation'),
            'si_code' => $request->get('si_code'),
            'pit_code' => $request->get('pit_code'),
            'birthday' => $request->get('birth_date'),
            'nationality' => $request->get('nationality'),
            'country_name_1' => $request->get('country_name_1'),
            'province_name_1' => $request->get('province_name_1'),
            'city_name_1' => $request->get('city_name_1'),
            'house_number_1' => $request->get('house_number_1'),
            'postal_code_1' => $request->get('postal_code_1'),
            'country_name_2' => $request->get('country_name_2'),
            'province_name_2' => $request->get('province_name_2'),
            'city_name_2' => $request->get('city_name_2'),
            'house_number_2' => $request->get('house_number_2'),
            'postal_code_2' => $request->get('postal_code_2'),
            'employee_id' => $id
        ]);
        $newPassword = bcrypt(value($request->get('password')));
        if ($newPassword!=" ") {
            $loginInformationData = ([
                'employee_id' => $id,
                'password' => $newPassword
            ]);
            LoginInformation::whereId($id)->update($loginInformationData);
        }
        return redirect('employees')->with('success', 'Employee is successfully updated');
    }


}
