@extends('layouts.app')
@section('title')
    {{ isset($emergencyContact)?'Update emergencyContact':'Create emergencyContact' }}
@endsection
@section('style')
    <style type="text/css">
        .err{
            color: red;
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container bootstrap snippet" style="background-color: antiquewhite; padding-bottom: 20px; margin-bottom: 20px;">
                    <center><h1>Relative information</h1></center>
                    <div style="margin-top: 10px">
                        <form method="post" action="{{ isset($emergencyContact)?route('emergency_contact.update',1):route('emergency_contact.store') }}">
                            @method(isset($emergencyContact)?'PUT':'post')
                            {{ csrf_field() }}
                            <div class="form-group">
                                {{-- Basic information --}}
                                <label class="col-xs-8 control-label" for="first_name" style="margin-left: 18px">First name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="{{ isset($emergencyContact)?$emergencyContact[0]->first_name:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="last_name" style="margin-left: 18px">Last name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="{{ isset($emergencyContact)?$emergencyContact[0]->last_name:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="relationship" style="margin-left: 18px">Relationship</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="relationship" name="relationship" value="{{ isset($emergencyContact)?$emergencyContact[0]->relationship:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="phone_number" style="margin-left: 18px">Phone number</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="phone_number" name="phone_number" value="{{ isset($emergencyContact)?$emergencyContact[0]->phone_number:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="email_address" style="margin-left: 18px">Email address</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="email_address" name="email_address" value="{{ isset($emergencyContact)?$emergencyContact[0]->email_address:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="country_name_1" style="margin-left: 18px">Country name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="country_name_1" name="country_name_1" value="{{ isset($emergencyContact)?$emergencyContact[0]->country_name_1:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="province_name_1" style="margin-left: 18px">Province name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="province_name_1" name="province_name_1" value="{{ isset($emergencyContact)?$emergencyContact[0]->province_name_1:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="city_name_1" style="margin-left: 18px">City name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="city_name_1" name="city_name_1" value="{{ isset($emergencyContact)?$emergencyContact[0]->city_name_1:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="house_number_1" style="margin-left: 18px">House number</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="house_number_1" name="house_number_1" value="{{ isset($emergencyContact)?$emergencyContact[0]->house_number_1:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="postal_code_1" style="margin-left: 18px">Postal code</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="postal_code_1" name="postal_code_1" value="{{ isset($emergencyContact)?$emergencyContact[0]->postal_code_1:'' }}" required>
                                </div>
                            </div>
                            <div class="col-xs-10">
                                <input type="hidden" value="{{ $id }}" name="employee_id">
                                <input type="hidden" value="{{ isset($emergencyContact)?$emergencyContact[0]->id:'' }}" name="employee_id">
                                <button type="submit" class="btn btn-primary" id="submit_btn">{{ isset($emergencyContact)?'Update':'Create' }}</button>
                                <button type="button" class="btn btn-danger" onclick="window.history.back();">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- Page script --}}
@section('script')
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script type="text/javascript">
{{--        using function password match or dont match --}}
        $(function () {
            $('#submit_btn').click(function () {
                var password = $('#password').val();
                var re_password = $('#re-password').val();
                if(password !== re_password){
                    $('.err').text(' * Password not match');
                    $('#re-password').focus();
                    return false;
                }

                var error = 0;
                $('form').find('input:text').each(function () {
                    if ($(this).val().trim().length == 0) {
                        $(this).focus();
                        error++;
                        return error;
                    }
                });
                if (error > 0){
                    return false;
                }
            });
            var menu = document.getElementById('menu-bar');
            var option = menu.getElementsByTagName('li');
            for (var i = 0; i < option.length; i++) {
                var current = document.getElementsByClassName("active");
                current[0].className = "";
                $('#employee_option').addClass("active");
            }
        });
        //using function only number input in text field
        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
        }
    </script>
@endsection
