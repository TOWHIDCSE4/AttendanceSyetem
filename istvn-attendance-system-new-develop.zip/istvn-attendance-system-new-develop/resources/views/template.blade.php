@extends('layouts/app')

{{-- Page internal style --}}
@section('style')
    <style>

    </style>
@endsection

{{-- Page content --}}
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="content-title">Test</h2>
                <p>Lorem ipsum...</p>
            </div>
        </div>
    </div>
@endsection

{{-- Page script --}}
@section('script')
    <script type="text/javascript">

    </script>
@endsection
