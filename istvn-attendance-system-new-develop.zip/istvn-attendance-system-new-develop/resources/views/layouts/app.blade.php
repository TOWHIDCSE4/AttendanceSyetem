<!DOCTYPE html>
<html lang="en" lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

{{--    <title>{{ config('app.name', 'ISTVN Attendance System') }}</title>--}}
    <title>@yield('title')</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">

    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!--rectangular font from adobe-->
    <link rel="stylesheet" href="https://use.typekit.net/bsc6fmm.css">

    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link rel="stylesheet" href="{{asset('css/navbar.css')}}">
    <!-- Add icon library -->
    <script src="https://kit.fontawesome.com/494023c1e7.js" crossorigin="anonymous"></script>

    @yield('style')


</head>

<body>

    {{-- temporary session data  --}}
    {{session()->put('position',3)}}

    <div id="wrapper">
        <aside id="sidebar-wrapper">
            <div class="sidebar-brand">
                <img class="brand-log" src="{{asset('images/ist.jpg')}}" alt="">
            </div>
            <ul class="sidebar-nav" id="menu-bar" style="margin-top:20px;">
                <li class="active">
                    <a href="{{ route('home') }}"><i class="fa fa-dashboard"></i>Dashboard</a>
                </li>

                {{-- part time employee special menu --}}
                @if (session()->get('position') == 0)
                <li>
                    <a href="#" role="button" aria-expanded="false" aria-controls="request" data-toggle="collapse"
                        data-target="#request"><i class="fa fa-paper-plane"></i>Request</a>
                    <div class="collapse ml-5 pl-3" id="request">
                        <a class="accordion-heading" href="#">Shift Change</a>
                        <a class="accordion-heading" href="#">Extra Time Work</a>
                    </div>
                </li>
                @endif

                {{-- Full time employee permission --}}
                @if (session()->get('position') > 0 )
                <li>
                    <a href="#" role="button" aria-expanded="false" aria-controls="request" data-toggle="collapse"
                        data-target="#request"><i class="fa fa-paper-plane"></i>Request</a>
                    <div class="collapse ml-5 pl-3" id="request">
                        <a class="accordion-heading" href="#">Status</a>
                        <a class="accordion-heading" href="#">Leave</a>
                        <a class="accordion-heading" href="#">Over Time Work</a>
                    </div>
                </li>
                @endif

                {{-- Manager level permission --}}
                @if (session()->get('position') > 1)
                <li>
{{--                    <a href=""><i class="fa fa-users"></i>Employee</a>--}}
                <li id="employee_option" class="">
                    <a href="{{ route('employees.index') }}"><i class="fa fa-users"></i>Employee</a>
                </li>
                @endif

                {{-- Admin level permission --}}
                @if (session()->get('position') > 2)
                <li id="department_option">
                    <a href="{{route('departments.index')}}"><i class="fa fa-landmark"></i>Department</a>
                </li>
                @endif

            </ul>
        </aside>

        <div id="navbar-wrapper">
            <nav class="navbar navbar-inverse">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <a href="#" class="nav-link pl-0" id="sidebar-toggle"><i class="fa fa-bars"></i></a>
                    </div>

                    <div class="justify-content-end">
                        <ul class="nav">
                            <li class="nav-item">
                                <a href="#" class="nav-link pl-0 pr-4"><i class="fa fa-bell"></i></a>
                            </li>

                            <li class="nav-item dropdown">
                                <a class="nav-link pl-0" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="fa fa-user-tie"></i> <span
                                        style="font-size:14pt; font-family:initial">User</span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{route('profile.update')}}">Profile Update</a>
{{--                                    <a class="dropdown-item" href="#">Logout</a>--}}
{{--                                    <a class="dropdown-item" href="#">Profile Update</a>--}}
                                    <a class="dropdown-item" href="javascript:void(0)" onclick="document.getElementById('logout-form').submit();">Logout</a>
                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>

        <section id="content-wrapper">
            @yield('content')
        </section>

    </div>

    {{-- all JavaScript --}}
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
        integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous">
    </script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
        integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous">

    </script>
    <script>
        $("#sidebar-toggle").click(function(e) {
    e.preventDefault();
    $("#wrapper").toggleClass("toggled");
});
    </script>

    @yield('script')

</body>

</html>
