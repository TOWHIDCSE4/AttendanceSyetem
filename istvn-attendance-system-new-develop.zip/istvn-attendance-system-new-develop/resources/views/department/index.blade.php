@extends('layouts/app')
@section('title')
    Department List
@endsection

{{-- Page internal style --}}
@section('style')
    <style>
        .input-wrapper div {

        }

        .remove-input {
            margin-top: 05px;
            margin-left: 05px;
            vertical-align: text-bottom;
            width: 18px;
        }

        .add-input {
            margin-top: 10px;
            margin-left: 10px;
            vertical-align: text-bottom;
            width: 18px;
        }
        .table-tr{
            background-color: thistle;
            font-weight: bold;
        }

    </style>
@endsection

{{-- Page content --}}
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <body style="background-color:whitesmoke">
                <div class="container" style="background-color:whitesmoke; margin-top: 8px">
                    <div class="container bootstrap snippet" style="background-color: antiquewhite;padding-bottom: 15px; ">
                        <center><h1>Department List</h1></center>
                        <a class="btn btn-success" style="background-color:#3d8c4f" href="javascript:void(0)"
                           id="createDepartment"> Create Department</a>
                        <div style="margin-top: 10px">
                            <table class="table table-bordered data-table table-responsive-lg" style="background-color: whitesmoke">
                                <thead>
                                <tr style="background-color:steelblue ">
                                    <th width="150px" style="text-align:center;">Department ID</th>
                                    <th style="text-align:center;">Department Name</th>
                                    <th width="280px" style="text-align:center;">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($departments as $key=>$department)
                                    <tr>
                                        <td class="table-tr" style="text-align:center;">{{$department->id}}</td>
                                        <td class="table-tr" width="280px"  >{{$department->department_name}}</td>
                                        <td width="280px" class="table-tr">
                                            <div class="row justify-content-center ">
                                                <a href="{{ route('departments.update', $department->id)}}" class="btn btn-primary" data-toggle="modal" data-target="#myModal_{{ $key }}" href="javascript:void(0)">Update</a> &nbsp;

                                                <a href="{{ route('departments.show', $department->id) }}" class="btn btn-primary">Section</a> &nbsp;
                                                <button class="btn btn-danger" type="button" data-toggle="modal" data-target="#deleteModal_{{ $key }}">Delete</button>
                                            </div>
                                            <br>
                                        </td>
                                    </tr>
                                    <!--Update department  Modal  -->
                                    <div class="modal fade" id="myModal_{{ $key }}" role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Update Department</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="post"
                                                          action="{{ route('departments.update', $department->id) }}">
                                                        @csrf
                                                        @method('PATCH')
                                                        <div class="form-group">
                                                            <label class="col-xs-8 control-label"
                                                                   style="margin-left: 18px">Department name </label>
                                                            <div class="col-sm-12">
                                                                <input type="text" class="form-control" name="department_name"
                                                                       placeholder="Enter Department Name"
                                                                       value="{{$department->department_name}}">
                                                            </div>
                                                        </div>

                                                        <div class="col-xs-10">
                                                            <button type="submit" class="btn btn-primary">Save</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!-- Delete modal popup -->
                                    <div class="modal fade" id="deleteModal_{{ $key }}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header alert alert-danger">
                                                    <h4 class="modal-title" id="myModalLabel">Delete Department</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="success-message">Are you sure you wish to delete this record ? </p>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="{{ route('departments.destroy', $department->id)}}" method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button class="btn btn-success delete-confirm">Yes</button>
                                                    </form>
                                                    <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End of the delete modal popup -->
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <!--create department  Modal  -->
                    <div class="modal fade" id="createDepartmentModal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="modelHeading"></h4>
                                </div>

                                <div class="modal-body">
                                    <form class="form-horizontal" method="post"
                                          action="{{ route('departments.store') }}" id="close_form">
                                        @csrf
                                        <div class="form-group">
                                            <label class="col-xs-8 control-label" style="margin-left: 18px">Department
                                                name </label>
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" name="department_name"
                                                       placeholder="Enter Department Name">
                                            </div>
                                        </div>
                                        <div class="col-xs-10">
                                            <button type="submit" class="btn btn-primary">Save
                                            </button>
                                            <button type="submit" class="btn btn-danger" data-dismiss="modal">Cancel
                                            </button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </body>
            </div>
        </div>
    </div>
@endsection

{{-- Page script --}}
@section('script')
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        // Using Model for Create Department and datatables
        $(function () {
            $('#createDepartment').click(function () {
                $('#saveBtn').val("create-department");
                $('#department_id').val('');
                $('#modelHeading').html("Create Department");
                $('#createDepartmentModal').modal('show');

            });


        });

        // This function use for Modal ''Department Section''
        $(document).ready(function () {
            var max_input_fields = 10;
            var add_input = $('.add-input');
            var input_wrapper = $('.input-wrapper');
            var new_input = '<div><input type="text" placeholder="Enter Department Section" style="\n' +
                '  width: 308px; \n' + '   margin-top: 10px; \n' + '   margin-left: 16px; \n' +
                '"  name="field[]"   value=""/><a href="javascript:void(0);"  class="remove-input" title="Remove input">' +
                '<img src="{{asset('images/remove.png')}}" style="\n' +
                '  width: 15px; \n' +
                '"></a></div>';
            var add_input_count = 1;
            $(add_input).click(function () {
                if (add_input_count < max_input_fields) {
                    add_input_count++;
                    $(input_wrapper).append(new_input);
                }

            });
            $(input_wrapper).on('click', '.remove-input', function (e) {
                e.preventDefault();
                $(this).parent('div').remove();

            });

            // This function use for Department side bar active
            $(function () {
                var menu = document.getElementById('menu-bar');
                var option = menu.getElementsByTagName('li');
                for (var i = 0; i < option.length; i++) {
                    var current = document.getElementsByClassName("active");
                    current[0].className = "";
                    $('#department_option').addClass("active");
                }
            });

        });

    </script>
@endsection
