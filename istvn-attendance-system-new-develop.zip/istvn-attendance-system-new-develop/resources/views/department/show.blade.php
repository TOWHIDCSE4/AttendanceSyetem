@extends('layouts/app')
@section('title')
    Section List
@endsection
@section('style')
    <style>
        .input-wrapper div {

        }

        .remove-input {
            margin-top: 05px;
            margin-left: 05px;
            vertical-align: text-bottom;
            width: 18px;
        }

        .add-input {
            margin-top: 10px;
            margin-left: 10px;
            vertical-align: text-bottom;
            width: 18px;
        }
        .btn-circle.btn-sm {
            width: 40px;
            height: 40px;
            padding: 6px 0px;
            border-radius: 15px;
            font-size: 20px;
            text-align: center;

        }
        .table-tr{
            background-color:thistle;
            font-weight: bold;
        }

    </style>
@endsection

{{-- Page content --}}
{{-- Page content --}}
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <body style="background-color:whitesmoke">
                <div class="container" style="background-color:whitesmoke; margin-top: 8px">
                    <div class="container bootstrap snippet" style="background-color: antiquewhite; padding-bottom: 15px;">
                        <center><h1>{{ $department->department_name }}</h1></center>
                        <a href="{{ route('departments.index') }}" class="close btn btn-danger btn-circle btn-sm">&times;</a>
                        <a class="btn btn-success" style="background-color:#3d8c4f" href="javascript:void(0)"
                           id="createSection"> Create Section</a>
                        <div style="margin-top: 10px">
                            <table class="table table-bordered data-table table-responsive-lg" style="background-color: whitesmoke">
                                <thead>
                                <tr style="background-color:steelblue ">
                                    <th width="150px" style="text-align:center;">Section ID</th>
                                    <th style="text-align:center;">Section Name</th>
                                    <th width="280px" style="text-align:center;">Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                @foreach($sections as $key=>$section)
                                    <tr >
                                        <td class="table-tr" style="text-align:center;">{{$section->id}}</td>
                                        <td class="table-tr"  width="280px" >{{$section->section_name}}</td>
                                        <td width="280px" class="table-tr" style="text-align:center;"><a href="{{ route('sections.update', $section->id)}}"
                                                                              class="btn btn-primary" data-toggle="modal"
                                                                              data-target="#myModal_{{ $key }}" href="javascript:void(0)">Update</a>

                                            <button class="btn btn-danger" type="button" data-toggle="modal" data-target="#deleteModal_{{ $key }}">Delete</button>
                                            <br>
                                        </td>
                                    </tr>
                                    <!--Update Section  Modal  -->
                                    <div class="modal fade" id="myModal_{{ $key }}" role="dialog">
                                        <div class="modal-dialog">

                                            <!-- Modal content-->
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Update Section</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <form method="post"
                                                          action="{{ route('sections.update', $section->id) }}">
                                                        @csrf
                                                        @method('PATCH')
                                                        <div class="form-group">
                                                            <label class="col-xs-8 control-label"
                                                                   style="margin-left: 18px">Section name </label>
                                                            <div class="col-sm-12">
                                                                <input type="text" class="form-control" name="section_name"
                                                                       placeholder="Enter Section Name"
                                                                       value="{{$section->section_name}}">
                                                                <input type="hidden" value="{{ $department->id }}" name="department_id">

                                                            </div>
                                                        </div>

                                                        <div class="col-xs-10">
                                                            <button type="submit" class="btn btn-primary">Save</button>
                                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                    <!-- Delete modal popup -->
                                    <div class="modal fade" id="deleteModal_{{ $key }}" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header alert alert-danger">
                                                    <h4 class="modal-title" id="myModalLabel">Delete Section</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <p class="success-message">Are you sure you wish to delete this record ? </p>
                                                </div>
                                                <div class="modal-footer">
                                                    <form action="{{ route('sections.destroy', $section->id)}}" method="post">
                                                        @csrf
                                                        @method('DELETE')
                                                        <button class="btn btn-success delete-confirm">Yes</button>
                                                        <input type="hidden" value="{{ $department->id }}" name="department_id">
                                                    </form>
                                                    <button class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End of the delete modal popup -->
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>


                    <!--create Section  Modal  -->
                    <div class="modal fade" id="createSectionModal">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4 class="modal-title" id="modelHeading"></h4>
                                </div>

                                <div class="modal-body">
                                    <form class="form-horizontal" method="post" action="{{ route('sections.store') }}" id="close_form">
                                        @csrf
                                        <div class="form-group">
                                            <label class="col-xs-8 control-label" style="margin-left: 18px">Section name </label>
                                            <div class="col-sm-12">
                                                <input type="text" class="form-control" name="section_name" placeholder="Enter Section Name">
                                                <input type="hidden" value="{{ $department->id }}" name="department_id">
                                            </div>
                                        </div>
                                        <div class="col-xs-10">
                                            <button type="submit" class="btn btn-primary">Save
                                            </button>
                                            <button type="submit" class="btn btn-danger" data-dismiss="modal">Cancel
                                            </button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </body>
            </div>
        </div>
    </div>
@endsection

{{-- Page script --}}
@section('script')
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
{{--        using javascript  create section and dataTables --}}
        $(function () {
            $('#createSection').click(function () {
                $('#saveBtn').val("create-section");
                $('#section_id').val('');
                $('#modelHeading').html("Create Section");
                $('#createSectionModal').modal('show');

            });

        });
    </script>
@endsection
