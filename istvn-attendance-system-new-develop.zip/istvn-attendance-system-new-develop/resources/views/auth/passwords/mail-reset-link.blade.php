<html>

<h1>Hello</h1>
<p style="font-size: 24px;">
    You are receiving this email because we received a password reset request for your account.<br>
    Please click reset button to reset your password <br>
    <button class="btn" type="submit"  style="background-color: #f44336; border: 0px; border-radius: 8px; height: 50px; color: white;">
        <a  href="{{ route('password.reset',[$token]) }}"  style="color: white; text-decoration: none;">Reset Password Link</a>
    </button>
</p>


</html>
