<!DOCTYPE html>
<html lang="en" lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>Reset your password</title>

    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <!--rectangular font from adobe-->
    <link rel="stylesheet" href="https://use.typekit.net/bsc6fmm.css">

    <link rel="stylesheet" href="{{asset('css/app.css')}}">
    <link rel="stylesheet" href="{{asset('css/navbar.css')}}">
    <!-- Add icon library -->
    <script src="https://kit.fontawesome.com/494023c1e7.js" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>

    @yield('style')


</head>

<body>

{{--@extends('layouts.app')--}}

{{--@section('content')--}}
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8" style="margin-top: 50px;">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="text-center">
                        {{ __('Reset Password') }}
                    </h4>
                </div>

                <div class="card-body">
                    <div class="alert alert-danger" role="alert" id="alert_error" style="text-align: center; display: none;"></div>
                    <form method="POST" action="{{ route('password.reset', $token) }}" onsubmit="return checkPassword();">
                        @csrf


                        <input type="hidden" name="token" value="{{ $token }}">

{{--                        <div class="form-group row">--}}
{{--                            <label for="email" class="col-md-4 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>--}}

{{--                            <div class="col-md-6">--}}
{{--                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus>--}}

{{--                                @error('email')--}}
{{--                                    <span class="invalid-feedback" role="alert">--}}
{{--                                        <strong>{{ $message }}</strong>--}}
{{--                                    </span>--}}
{{--                                @enderror--}}
{{--                            </div>--}}
{{--                        </div>--}}

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Reset Password') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
{{--@endsection--}}

{{--Password Validation--}}
<script type="text/javascript">
    function checkPassword() {
        var password = $('#password').val();
        var password_confirm = $('#password-confirm').val();
        if(password != password_confirm){
            $('#alert_error').css('display','block');
            $('#alert_error').text('Password not match');
            $('#password-confirm').focus();
            return false;
        }
    }
</script>
</body>
