@extends('layouts/app')

{{-- Page internal style --}}
@section('style')
    <style>
    </style>
@endsection

{{-- Page content --}}
@section('content')
    <div class="container-fluid" style="background-color: cadetblue">
        <div class="row">
            <div class="col-lg-12">

                <hr>
                <div class="container bootstrap snippet" style="background-color: cadetblue">
                    <div class="row">
                        <div class="col-sm-10"><h1>Profile Update</h1></div>

                    </div>
                    <div class="row" style="background-color: antiquewhite">
                        <div class="col-sm-3"><!--left col-->


                            <div class="text-center">
                                <img  id="blah" src="http://ssl.gstatic.com/accounts/ui/avatar_2x.png" class="avatar img-circle img-thumbnail" alt="avatar">
                                <input type="file" id="file" name="image_path" multiple onchange="readURL(this);"class="text-center center-block file-upload">
                            </div></hr><br>




                        </div><!--/col-3-->
                        <div class="col-sm-9">

                            <div class="tab-content">
                                <div class="tab-pane active" id="home">
                                    <hr>
                                    <form class="form"action="{{ route('profile.update') }}" method="post">

                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                    <label for="employee_id"><h6>First name</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="First name">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Last name</h6></label>
                                                <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="Last name">
                                            </div>
                                        </div>

                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Birth Date</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Birth Date">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Email</h6></label>
                                                <input type="email" id="defaultRegisterFormLastName" class="form-control" placeholder="you@email.com">
                                            </div>
                                        </div>


                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Phone Number</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Phone Number">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Address</h6></label>
                                                <textarea type="email" class="form-control" placeholder="Address" ></textarea>
                                            </div>
                                        </div>

                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Parent ID</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Parent ID">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Parent type</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Parent type">
                                            </div>
                                        </div>


                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Relationship</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Relationship">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Employee Type</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Employee Type">
                                            </div>
                                        </div>

                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Residence Card/Passport Number</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Residence Card/Passport Number">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Personal Income Tax code</h6></label>
                                                <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="Personal Income Tax code">
                                            </div>
                                        </div>


                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Gender</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Gender">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Date of Join in Office</h6></label>
                                                <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="Date of Join in Office">
                                            </div>
                                        </div>


                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Designation of Employee</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Designation of Employee">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Social insurance Number</h6></label>
                                                <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="Social insurance Number">
                                            </div>
                                        </div>


                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Display Name</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Display Name">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Role Name</h6></label>
                                                <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="Role Name">
                                            </div>
                                        </div>


                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Section Name</h6></label>
                                                <input type="text" id="defaultRegisterFormFirstName" class="form-control" placeholder="Section Name">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Department Name</h6></label>
                                                <input type="text" id="defaultRegisterFormLastName" class="form-control" placeholder="Department Name">
                                            </div>
                                        </div>

                                        <div class="form-row mb-4">
                                            <div class="col">
                                                <!-- First name -->
                                                <label for="employee_id"><h6>Password</h6></label>
                                                <input type="password" class="form-control" name="password"  placeholder="password" title="enter your password.">
                                            </div>
                                            <div class="col">
                                                <!-- Last name -->
                                                <label for="employee_id"><h6>Confirm Password</h6></label>
                                                <input type="password" class="form-control" name="password2"  placeholder="Confirm Password" title="enter your password2.">
                                            </div>
                                        </div>

                                        <div class="form-group">
                                            <div class="col-xs-12">
                                                <br>
                                                <button class="btn btn-lg btn-success" type="submit"><i class="glyphicon glyphicon-ok-sign"></i> Update </button>
                                            </div>
                                        </div>

                                    </form>
                                </div>

                            </div><!--/tab-pane-->
                        </div><!--/tab-content-->

                    </div><!--/col-9-->
                </div><!--/row-->


            </div>
        </div>
    </div>
@endsection

{{-- Page script --}}
@section('script')
    <script type="text/javascript">
        function myFunction() {
            var x = document.getElementById("myDate").value;
            document.getElementById("demo").innerHTML = x;
        }


        function readURL(input) {                                                            {{--  Image Size smaller 2MB For using javascript --}}
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            if (input.files[0].size >20000) {
                alert("File size must 2MB or below  ");
                input.value = "";
            }else{
                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                };
                reader.readAsDataURL(input.files[0]);
            }
        }
        }

    </script>
@endsection
