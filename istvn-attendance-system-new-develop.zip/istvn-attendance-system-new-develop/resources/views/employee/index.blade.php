@extends('layouts.app')
@section('title')
    Employee list
@endsection
@section('style')
    <style type="text/css">
        .table-tr{
            background-color: thistle;
            /*font-weight: bold;*/
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
@endsection

@section('content')
    <div class="container-fluid">
        @if(session('success'))
            <div class="alert alert-success" role="alert" style="text-align: center;">
                {{ session('success') }}
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            </div>
        @endif
        <div class="row">
            <div class="col-lg-12">
                <div class="container-fluid bootstrap snippet" style="background-color: antiquewhite; padding-bottom: 20px;">
                    <center><h1>Employees List</h1></center>
                    <form action="{{ route('employees.create') }}">
                        <button class="btn btn-success" data-toggle="modal" data-target="#createModal">Create Employee</button>
                    </form>
                    <div style="margin-top: 10px" class="table-responsive">
                        <table class="table table-bordered data-table" style="background-color: whitesmoke; text-align: center; white-space: nowrap;">
                            <thead>
                            <tr  style="background-color:steelblue ">
                                <th>ID</th>
                                <th>Email address</th>
                                <th>First name</th>
                                <th>Last name</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Section</th>
                                <th >Status</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($employees as $key=>$row)


                                <tr>
                                    <td>{{ $row->id }}</td>
                                    <td>{{ $row->email_address }}</td>
                                    <td>{{ $row->first_name }}</td>
                                    <td>{{ $row->last_name }}</td>
                                    <td>{{ $row->role->display_name }}</td>
                                    <td>{{ isset($row->department) ? $row->department->department_name : "" }}</td>
                                    <td>{{ $row->section->section_name }}</td>
                                    <td id="demo">{{ $row->employeeStatus->status_name }}</td>
                                    <td style="padding-left: 10px; padding-right: 10px;">

                                        <div class="row justify-content-center">
                                            <form action="{{ route('employees.edit',$row->id) }}" method="get">
                                                <button class="btn btn-primary" type="submit">Update</button>
                                            </form> &nbsp;
{{--                                            @if($row->user_id == '')--}}
{{--                                                <form action="{{ route('users.create') }}">--}}
{{--                                                    <input type="hidden" value="{{ $row->id }}" name="employee_id">--}}
{{--                                                    <button class="btn btn-success" type="submit">Add user</button>--}}
{{--                                                </form> &nbsp;--}}
{{--                                            @endif--}}
                                        @if($row->user_id != '')
                                                <form action="{{ route('users.edit',$row->user_id) }}">
                                                    <button class="btn btn-success" type="submit">Update user</button>
                                                </form> &nbsp;
                                            @endif


                                            @isset($row->emergencyContact)
                                                <form action="{{ route('emergency_contact.edit',$row->id ) }}" method="get">
                                                    <input type="hidden" value="1" name="employee_id">
                                                    <button class="btn btn-success" type="submit">Relative Update</button>
                                                </form> &nbsp;
                                            @else
                                                <form action="{{ route('emergency_contact.create',$row->id) }}" method="get">
                                                    <input type="hidden" value="1"  name="employee_id">
                                                    <button class="btn btn-success" type="submit">Relative Add</button>
                                                </form> &nbsp;
                                            @endif

                                            @endforeach
                                        </div>
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- Page script --}}
@section('script')
    <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
    <script type="text/javascript">
        $(function () {
            var menu = document.getElementById('menu-bar');
            var option = menu.getElementsByTagName('li');
            for (var i = 0; i < option.length; i++) {
                var current = document.getElementsByClassName("active");
                current[0].className = "";
                $('#employee_option').addClass("active");
            }
            setTimeout(function() {
                $('.alert').fadeOut();
            }, 3000);
        });
        $(document).ready(function() {
            $('.table').DataTable();
        } );



        function myFunction() {
            document.getElementById("demo").innerHTML = "inactive";
        }


    </script>
@endsection
