@extends('layouts.app')

@section('title')
    Update employee
@endsection

@section('style')
    <style type="text/css">
    </style>
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container bootstrap snippet" style="background-color: antiquewhite;  padding-bottom: 20px; margin-bottom: 20px;">
                    <center><h1>Update Employee</h1></center>
                    <div style="margin-top: 10px">
                        <form method="post" action="{{ route('employees.update',$employee->id) }}">
                            @csrf
                            @method('PUT')
                            <div class="form-group">
                                {{-- Basic information --}}
                                <label class="col-xs-8 control-label" for="first_name" style="margin-left: 18px">First name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="first_name" name="first_name" value="{{ $basic[0]->first_name }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="last_name" style="margin-left: 18px">Last name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="last_name" name="last_name" value="{{ $basic[0]->last_name }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="phone" style="margin-left: 18px">Phone</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="phone" name="phone" value="{{ $basic[0]->phone }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="address" style="margin-left: 18px">Address</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="address" name="address" value="{{ $basic[0]->address }}" required>
                                </div>
                                <input type="hidden" value="" name="basic_id">
                                <br>

                                {{-- Employee information --}}
                                <label class="col-xs-8 control-label" for="datepicker" style="margin-left: 18px">Date of birth </label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="datepicker" name="birth_date" value="{{ $employee->birth_date }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="email" style="margin-left: 18px">Email address </label>
                                <div class="col-sm-12">
                                    <input type="email" class="form-control" id="email" name="email_address" value="{{ $employee->email_address }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="civilian" style="margin-left: 18px">Civilian ID </label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="civilian" name="civilian_id" value="{{ $employee->civilian_id }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="pit_code" style="margin-left: 18px">Personal income tax code</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="pit_code" name="pit_code" value="{{ $employee->pit_code }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="gender" style="margin-left: 18px">Gender</label>
                                <div class="col-sm-12">
                                    <select name="gender" id="gender" class="form-control">
                                        <option value="">-- Select gender --</option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                    </select>
                                </div>
                                <label class="col-xs-8 control-label" for="datepicker_2" style="margin-left: 18px">Join date</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="datepicker_2" name="join_date" value="{{ $employee->join_date }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="designation" style="margin-left: 18px">Designation</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="designation" name="designation" value="{{ $employee->designation }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="si_code" style="margin-left: 18px">Social insurance number</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="si_code" name="si_code" value="{{ $employee->si_code }}" required>
                                </div>
                            </div>
                            <div class="col-xs-10">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <button type="button" class="btn btn-danger" onclick="window.history.back();">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- Page script --}}
@section('script')
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet prefetch" href="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript">
        $( function() {
            $( "#datepicker" ).datepicker({
                format:'yyyy-mm-dd',
                autoclose: true,
                endDate:"today"
            });
            $( "#datepicker_2" ).datepicker({
                format:'yyyy-mm-dd',
                autoclose: true,
                endDate:"today"
            });
            var menu = document.getElementById('menu-bar');
            var option = menu.getElementsByTagName('li');
            for (var i = 0; i < option.length; i++) {
                var current = document.getElementsByClassName("active");
                current[0].className = "";
                $('#employee_option').addClass("active");
            }
        } );
    </script>
@endsection