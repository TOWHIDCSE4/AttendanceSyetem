@extends('layouts.app')

@section('title')
    {{ isset($employee)?'Update employee':'Create employee' }}
@endsection

@section('style')
    <style type="text/css">
    </style>
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container bootstrap snippet"
                     style="background-color: antiquewhite; padding-bottom: 20px; margin-bottom: 20px;">
                    <center><h1>Create Employee</h1></center>
                    <div style="margin-top: 10px">
                        <form method="post"
                              action="{{ isset($employee)?route('employees.update',1):route('employees.store') }}">
                            @method(isset($employee)?'PUT':'post')
                            {{ csrf_field() }}

                            <div class="form-group">
                                {{-- Employee --}}
                                <label class="col-xs-8 control-label" for="user_id" style="margin-left: 18px">User
                                    ID</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="user_id" name="user_id"
                                           value="{{ isset($employee) ? $employee->id:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="email_address" style="margin-left: 18px">Email
                                    address</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="email_address" name="email_address"
                                           value="{{ isset($employee) ? $employee->email_address:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="first_name" style="margin-left: 18px">First
                                    Name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="first_name" name="first_name"
                                           value="{{ isset($employee) ? $employee->first_name:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="last_name" style="margin-left: 18px">Last
                                    Name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="last_name" name="last_name"
                                           value="{{ isset($employee) ? $employee->last_name:'' }}" required>
                                </div>
                                <label class="col-xs-8 control-label" for="role_id"
                                       style="margin-left: 18px">Role</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="role_id" id="role_id"
                                            required>
                                        <option value="" style="display: none;">-- Select role --</option>
                                        @foreach($role as $row)
                                            <option value="{{ $row->id }}" selected>{{ $row->display_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <label class="col-xs-8 control-label" for="dept_id"
                                       style="margin-left: 18px">Department</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="dept_id" id="dept_id" required>
                                        <option value="" style="display: none;">-- Select department --</option>
                                        @foreach($department as $row)
                                            <option value="{{ $row->id }}" selected>{{ $row->department_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <label class="col-xs-8 control-label" for="sec_id"
                                       style="margin-left: 18px">Section</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="sec_id" id="sec_id" required>
                                        <option value="" style="display: none;">-- Select section --</option>
                                        @foreach($section as $row)
                                            <option value="{{ $row->id }}" selected>{{ $row->section_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <label class="col-xs-8 control-label" for="employee_type" style="margin-left: 18px">Employee
                                    type</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="employee_type" id="employee_type"
                                            value="{{ isset($employee) ? $employee->employee_type:'' }}" required>
                                        <option value="" style="display: none;">-- Select department --</option>
                                        <option value="1" selected>Part time</option>
                                        <option value="1" selected>Full time</option>
                                    </select>
                                </div>
                                <label class="col-xs-8 control-label" for="employee_status_id"
                                       style="margin-left: 18px">User
                                    status</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="employee_status_id" id="employee_status_id"
                                            required>
                                        <option value="" style="display: none;">-- Select status --</option>
                                        @foreach($employeeStatus as $row)
                                            <option value="{{ $row->id }}" selected>{{ $row->status_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <br>
                                {{-- Login information --}}

                                <label class="col-xs-8 control-label" for="password"
                                       style="margin-left: 18px">Password</label>
                                <div class="col-sm-12">
                                    <input type="password" class="form-control" id="password" name="password"
                                           value="" {{ isset($employee)?' ':'required' }}>
                                </div>

                                <label class="col-xs-8 control-label" for="confirm_password" style="margin-left: 18px">Comfirm
                                    password</label>
                                <div class="col-sm-12">
                                    <input type="password" class="form-control" id="confirm_password"
                                           name="confirm_password"
                                           value="" value="" {{ isset($employee)?' ':'required' }}>
                                </div>
                                <span id='message'></span>
                                <br>

                                {{-- Employee information --}}
                                <label class="col-xs-8 control-label" for="phone_number" style="margin-left: 18px">Phone
                                    number</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="phone_number" name="phone_number"
                                           onkeypress="return isNumberKey(event)"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->phone_number:'' }}"
                                           required>
                                </div>

                                <label class="col-xs-8 control-label" for="residence_number" style="margin-left: 18px">Residence
                                    number </label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="residence_number"
                                           name="residence_number"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->residence_number:'' }}"
                                           required>
                                </div>

                                <label class="col-xs-8 control-label" for="passport_number" style="margin-left: 18px">Passport
                                    number </label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="passport_number" name="passport_number"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->passport_number:'' }}">
                                </div>

                                <label class="col-xs-8 control-label" for="gender"
                                       style="margin-left: 18px">Gender</label>
                                <div class="col-sm-12">
                                    <select name="gender" id="gender" class="form-control">
                                        <option value="" style="display: none;">-- select gender --</option>
                                        <option value="male" selected>Male</option>
                                        <option value="female" selected>Female</option>
                                    </select>
                                </div>

                                <label class="col-xs-8 control-label" for="datepicker_2" style="margin-left: 18px">Join
                                    date</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="datepicker_2" name="join_date"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->join_date:'' }}"
                                           readonly
                                           style="background-color: white;">
                                </div>

                                <label class="col-xs-8 control-label" for="datepicker_3" style="margin-left: 18px">Quit
                                    date</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="datepicker_3" name="quit_date"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->job_quit_date:'' }}"
                                           readonly
                                           style="background-color: white;">
                                </div>

                                <label class="col-xs-8 control-label" for="designation" style="margin-left: 18px">Designation</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="designation" name="designation"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->designation:'' }}">
                                </div>

                                <label class="col-xs-8 control-label" for="si_code" style="margin-left: 18px">Social
                                    insurance number</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="si_code" name="si_code"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->si_code:'' }}">
                                </div>

                                <label class="col-xs-8 control-label" for="pit_code" style="margin-left: 18px">Personal
                                    income tax code</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="pit_code" name="pit_code"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->pit_code:'' }}">
                                </div>

                                <label class="col-xs-8 control-label" for="datepicker" style="margin-left: 18px">Date of
                                    birth </label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="datepicker" name="birth_date"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->birthday:'' }}"
                                           readonly
                                           style="background-color: white;">
                                </div>

                                <label class="col-xs-8 control-label" for="nationality" style="margin-left: 18px">Nationality</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="nationality" name="nationality"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->nationality:'' }}">
                                </div>

                                <label class="col-xs-8 control-label" for="country_name_1" style="margin-left: 18px">Country
                                    name 1</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="country_name_1" name="country_name_1"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->country_name_1:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="province_name_1" style="margin-left: 18px">Province
                                    name 1</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="province_name_1" name="province_name_1"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->province_name_1:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="city_name_1" style="margin-left: 18px">City
                                    name 1</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="city_name_1" name="city_name_1"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->city_name_1:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="house_number_1" style="margin-left: 18px">House
                                    number 1</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="house_number_1" name="house_number_1"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->house_number_1:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="postal_code_1" style="margin-left: 18px">Postal
                                    code 1</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="postal_code_1" name="postal_code_1"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->postal_code_1:'' }}">
                                </div>

                                <label class="col-xs-8 control-label" for="country_name_2" style="margin-left: 18px">Country
                                    name 2</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="country_name_2" name="country_name_2"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->country_name_2:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="province_name_2" style="margin-left: 18px">Province
                                    name 2</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="province_name_2" name="province_name_2"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->province_name_2:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="city_name_2" style="margin-left: 18px">City
                                    name 2</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="city_name_2" name="city_name_2"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->city_name_2:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="house_number_2" style="margin-left: 18px">House
                                    number 2</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="house_number_2" name="house_number_2"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->house_number_2:'' }}">
                                </div>
                                <label class="col-xs-8 control-label" for="postal_code_2" style="margin-left: 18px">Postal
                                    code 2</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="postal_code_2" name="postal_code_2"
                                           value="{{ isset($employeeInformation) ? $employeeInformation->postal_code_2:'' }}">
                                </div>

                            </div>
                            <div id="err"></div>
                            <br>
                            <div class="col-xs-10">
                                <button type="submit" class="btn btn-primary"
                                        id="submit_btn">{{ isset($employee)?'Update':'Create' }}</button>
                                <button type="button" class="btn btn-danger" onclick="window.history.back();">Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- Page script --}}
@section('script')
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet prefetch"
          href="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css">
    <script src="http://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
    <script type="text/javascript">

        $('#password, #confirm_password').on('keyup', function () {
            if ($('#password').val() == $('#confirm_password').val()) {
                $('#message').html('Matched').css('color', 'green');
            } else
                $('#message').html('Not Matched').css('color', 'red');
        });
        $(function () {
            $("#datepicker").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                endDate: "today"
            });
            $("#datepicker_2").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                endDate: "today"
            });
            $("#datepicker_3").datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                endDate: "today"
            });
            var menu = document.getElementById('menu-bar');
            var option = menu.getElementsByTagName('li');
            for (var i = 0; i < option.length; i++) {
                var current = document.getElementsByClassName("active");
                current[0].className = "";
                $('#employee_option').addClass("active");
            }

            // $('#submit_btn').click(function () {
            //     var error = 0;
            //     var form = $('form');
            //     form.find('input[type=email]').each(function () {
            //         if ($(this).val().trim().length === 0) {
            //             error++;
            //             return error;
            //         }
            //     });
            //     form.find('input:text').each(function () {
            //         if ($(this).val().trim().length === 0) {
            //             error++;
            //             return error;
            //         }
            //     });
            //     if (error > 0) {
            //         var err = $('#err');
            //         err.text('* Please enter all information !!!');
            //         err.css('color', 'red');
            //         return false;
            //     }
            // });

        });

        function isNumberKey(evt) {
            var charCode = (evt.which) ? evt.which : event.keyCode;
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
        }
    </script>
@endsection
