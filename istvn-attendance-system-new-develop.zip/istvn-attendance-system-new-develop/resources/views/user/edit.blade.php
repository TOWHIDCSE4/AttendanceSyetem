@extends('layouts.app')

@section('title')
    Update user
@endsection

@section('style')
    <style type="text/css">
        .err{
            color: red;
        }
        i.fas{
            position: absolute;
            right: 30px;
            margin-top: -25px;
            cursor: pointer;
        }
    </style>
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="container bootstrap snippet" style="background-color: antiquewhite; padding-bottom: 20px; margin-bottom: 20px;">
                    <center><h1>Create Employee</h1></center>
                    <div style="margin-top: 10px">
                        <form method="post" action="{{ route('users.update',$user->id) }}">
                            @csrf
                            @method('PUT')
                            <div class="form-group">
                                <label class="col-xs-8 control-label" for="user_name" style="margin-left: 18px">User name</label>
                                <div class="col-sm-12">
                                    <input type="text" class="form-control" id="user_name" name="user_name" required value="{{ $user->user_name }}">
                                </div>
                                <label class="col-xs-8 control-label" for="password" style="margin-left: 18px">Password</label>
                                <div class="col-sm-12">
                                    <input type="password" class="form-control" id="password" name="password">
                                    <i class="fas fa-eye" id="password-eye"></i>
                                    <div id="error">
                                        <ul>
                                            <li id="letter">One or more lowercase letters</li>
                                            <li id="capital">One or more uppercase letters</li>
                                            <li id="number">One or more numbers</li>
                                            <li id="length">8 characters or more</li>
                                        </ul>
                                    </div>
                                </div>
                                <label class="col-xs-8 control-label" for="re-password" style="margin-left: 18px">Re-enter Password</label>
                                <div class="col-sm-12">
                                    <input type="password" class="form-control" id="re-password">
                                    <i class="fas fa-eye" id="re-password-eye"></i>
                                    <div class="err"></div>
                                </div>
                                <label class="col-xs-8 control-label" for="role_id" style="margin-left: 18px">Role</label>
                                <div class="col-sm-12">
                                    <select class="form-control" name="role_id" id="role_id" required>
                                        <option value="" style="display: none;">-- Select role --</option>
                                        @foreach($role as $row)
                                            <option value="{{ $row->id }}" @if($user->role_id == $row->id) selected @endif>{{ $row->display_name }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="col-xs-10">
                                <button type="submit" class="btn btn-primary" id="updateBtn">Update</button>
                                <button type="button" class="btn btn-danger" onclick="window.history.back();">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
{{-- Page script --}}
@section('script')
    <script src="https://code.jquery.com/jquery-3.4.1.js"></script>
    <script type="text/javascript">
        $(function () {
            $('#createBtn').click(function () {
                var password = $('#password').val();
                var re_password = $('#re-password').val();
                if(password !== re_password){
                    $('.err').text(' * Password not match');
                    re_password.focus();
                    return false;
                }
            });
            var menu = document.getElementById('menu-bar');
            var option = menu.getElementsByTagName('li');
            for (var i = 0; i < option.length; i++) {
                var current = document.getElementsByClassName("active");
                current[0].className = "";
                $('#employee_option').addClass("active");
            }
            $('#error').hide();
            $('#password').keyup(function () {
                var pw = $('#password').val();
                var lower_text = new RegExp('[a-z]');
                var upper_text = new RegExp('[A-Z]');
                var number = new RegExp('[0-9]');
                var flag = 'T';
                if (pw.match(lower_text)){
                    $('#letter').css('color','green');
                }else{
                    $('#letter').css('color','red');
                    flag = 'F';
                }

                if (pw.match(upper_text)){
                    $('#capital').css('color','green');
                }else{
                    $('#capital').css('color','red');
                    flag = 'F';
                }

                if (pw.match(number)){
                    $('#number').css('color','green');
                }else{
                    $('#number').css('color','red');
                    flag = 'F';
                }

                if(pw.length >= 8){
                    $('#length').css('color','green');
                }else{
                    $('#length').css('color','red');
                    flag = 'F';
                }

                if(pw.length != 0 && flag == 'F'){
                    $('#updateBtn').attr('disabled','true');
                    $('#error').fadeIn(10);
                }else{
                    $('#updateBtn').removeAttr('disabled');
                    $('#error').fadeOut(10);
                }
            });

            $('#password-eye').click(function () {
                var pw_type = $('#password');
                if(pw_type.attr('type') === 'password'){
                    pw_type.attr('type','text');
                    $(this).attr('class','fas fa-eye-slash');
                }else{
                    pw_type.attr('type','password');
                    $(this).attr('class','fas fa-eye');
                }
            });
            $('#re-password-eye').click(function () {
                var pw_type = $('#re-password');
                if(pw_type.attr('type') === 'password'){
                    pw_type.attr('type','text');
                    $(this).attr('class','fas fa-eye-slash');
                }else{
                    pw_type.attr('type','password');
                    $(this).attr('class','fas fa-eye');
                }
            });
        });
    </script>
@endsection