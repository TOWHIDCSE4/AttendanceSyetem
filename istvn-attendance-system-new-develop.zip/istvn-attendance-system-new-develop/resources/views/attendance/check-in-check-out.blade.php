@extends('layouts/app')
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<!-- XDSoft DateTimePicker -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.min.css" integrity="sha256-DOS9W6NR+NFe1fUhEE0PGKY/fubbUCnOfTje2JMDw3Y=" crossorigin="anonymous" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.min.js" integrity="sha256-FEqEelWI3WouFOo2VWP/uJfs1y8KJ++FLh2Lbqc8SJk=" crossorigin="anonymous"></script>

@section('style')
    <style>
        .register{
            background: -webkit-linear-gradient(left, #3931af, #00c6ff);
            margin-top: 3%;
            padding: 3%;
        }
        .register-left{
            text-align: center;
            color: #fff;
            margin-top: 4%;
        }
        .register-left input{
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
            width: 60%;
            background: #f8f9fa;
            font-weight: bold;
            color: #383d41;
            margin-top: 30%;
            margin-bottom: 3%;
            cursor: pointer;
        }
        .register-right{
            background: #f8f9fa;
            border-top-left-radius: 10% 50%;
            border-bottom-left-radius: 10% 50%;
        }

        @-webkit-keyframes mover {
            0% { transform: translateY(0); }
            100% { transform: translateY(-20px); }
        }
        @keyframes mover {
            0% { transform: translateY(0); }
            100% { transform: translateY(-20px); }
        }
        .register-left p{
            font-weight: lighter;
            padding: 12%;
            margin-top: -9%;
        }
        .register .register-form{
            padding: 10%;
            margin-top: 10%;
        }
        .btnRegister{
            float: right;
            margin-top: 10%;
            border: none;
            border-radius: 1.5rem;
            padding: 2%;
            background: #0062cc;
            color: #fff;
            font-weight: 600;
            width: 50%;
            cursor: pointer;
        }


        .register-heading{
            text-align: center;
            margin-top: 8%;
            margin-bottom: -15%;
            color: #495057;
        }
    </style>
@endsection

{{-- Page content --}}
@section('content')
    <div class="container-fluid">
        <div class="container register">
            <div class="row">
                <div class="col-md-3 register-left">

                </div>
                <div class="col-md-9 register-right">

                    <div class="tab-content" id="myTabContent">
                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                            <h3 class="register-heading">Check In and Check Out</h3>
                            <div class="row register-form">
                                <div class="col-md-6">

                                    <div class="form-group row">
                                        <label for="staticEmail" style="font-weight: bold;" class="col-sm-6 col-form-label">Current Date :</label>
                                        <div class="col-sm-6">
                                            <input type="text" readonly class="form-control-plaintext" type="date" id="currentDate" disabled="disabled">
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="staticEmail" style="font-weight: bold;" class="col-sm-6 col-form-label">Check In Time : </label>
                                        <div class="col-sm-6">
                                            <input type="text" readonly class="form-control-plaintext" type="date" id="currentTime" disabled="disabled">
                                        </div>
                                    </div>


                                    <input type="submit" class="btnRegister"  value="Check In"/>

                                </div>

                                <div class="col-md-6">
                                    <div class="form-group row">
                                        <label for="staticEmail" style="font-weight: bold;" class="col-sm-6 col-form-label">Current Day :  </label>
                                        <div class="col-sm-6" style=" top: 7px;">
                                            <script type="text/javascript">
                                                var myDate = new Date();
                                                var myDay = myDate.getDay();
                                                // Array of days.
                                                var weekday = ['Sunday', 'Monday', 'Tuesday',
                                                    'Wednesday', 'Thursday', 'Friday', 'Saturday'
                                                ];
                                                document.write("" + weekday[myDay]);
                                                document.write("<br/>");
                                            </script>


                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="staticEmail" style="font-weight: bold;" class="col-sm-6 col-form-label">Check Out Time: </label>
                                        <div class="col-sm-6">
                                            <input type="text" readonly class="form-control-plaintext" type="date" id="currentTime1" disabled="disabled">
                                        </div>
                                    </div>
                                    <input type="submit" class="btnRegister"  value="Check Out"/>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    </div>
@endsection

{{-- Page script --}}
@section('script')
    <script type="text/javascript">
        // current date ,time and day using javascript
        var date = new Date();
        var currentDate = date.toISOString().slice(0,10);
        var currentTime = date.getHours() + ':' + date.getMinutes();
        var currentTime1 = date.getHours() + ':' + date.getMinutes();
        document.getElementById('currentDate').value = currentDate;
        document.getElementById('currentTime').value = currentTime;
        document.getElementById('currentTime1').value = currentTime1;
    </script>
@endsection




































