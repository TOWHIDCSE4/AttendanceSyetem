# istvn-attendance-system-new

# I. Create project in local from gitlab
1.Clone project from develop branch
 
     
    git clone https_link
    
![image](images/clone.png)
    
2.Move to project file

    cd project_file_name
    
![image](images/cd.png)
    
3.Update composer
- after clone project, the vendor file will be missing, so you need update file by command:
 

    composer update
    
![image](images/composer.png)
    
4.Create new branch

    git checkout -b branch_name
    
after run command, you can see new branch in gitlab

ex: create branch name 'phanbinh': 

git checkout -b phanbinh 

![image](images/new_branch.png)
    
    
- if branch already exists, you can switch to that branch by:
     
     
    git checkout branch_name
    
![image](images/branch.png)
    
5.Insert data to new branch

    git add .
    git commit -m 'message'
    
- To avoid code conflicts, you should pull the code from the development branch before pushing it up
    
    
    
        git pull origin branch_development_name
    
    
- Pushing code to git:


    
        git push origin branch_name
    
    
![image](images/branch.png)
    
    
6.Checking status

    git status
    
![image](images/status.png)

# II. Create database

1.Create empty database in php my admin

![image](images/database.png)

![image](images/empty_db.png)

2.Change database name in .env file

![image](images/env.png)

3.Create migration

    php artisan make:migration migration_name --create=table_name
    
ex: php artisan make:migration create_user_table --create=user

The file will be create in database/migrations

You can create create data columns in here

![image](images/migration.png)

![image](images/migrate.png)

- run migration to create table


        php artisan migrate 

![image](images/run_migrate.png)

![image](images/database_run.png)

4.Create Model

    php artisan make:model Model_name

ex: php artisan make:model User

The file will be create in app/

![image](images/model.png)

![image](images/model_code.png)

5.Create Seeder

Seeder will contain the sample data you want to add
    php artisan make:seed Seeder_name
    
ex: create seeder for user table:

php artisan make:seed UserSeeder

The file will be create in database/seeds

![image](images/create_seed.png)

![image](images/seed.png)

7.Call class seeder to run

Call class in file: database/seeds/DatabaseSeeder.php

![image](images/data_seeder.png)

8.Run seed to add data

    php artisan db:seed
    
![image](images/run_seed.png)

![image](images/database_run.png)

after run this command, data will be insert into table

![image](images/data_insert.png)

- Run single class:

    
        php artisan db:seed --class=Seeder_name 
    
ex: insert data into User table:
 
php artisan db:seed --class=UserSeeder

- You can refresh database by command:


        php artisan migrate:fresh --seed
    
![image](images/refresh.png)

# III. PHP static code analysis by PHPCS

1. PHPCS

Install by composer

    composer require --dev squizlabs/php_codesniffer
    
Now create a controller by artisan like php artisan make:controller TestController And modify controller like bellow.

    namespace AppHttpControllers;
    
    use IlluminateHttpRequest;
    
    class testController extends Controller
    {
        private function testTest(){
        }
    }

Run PHPCS on terminal

    ./vendor/bin/phpcs app/Http/Controllers/TestController.php

Some error will display on terminal also you will get a message on bottom of report that some error could be fixed automatically To automatically fix those error run this command.


    ./vendor/bin/phpcbf app/Http/Controllers/TestController.php


Automatically some error will be fixed. we can make a configure file to make it more simple make a phpcs.xml file on top of root directory and write this code


    <?xml version="1.0"?>
    <ruleset name="PSR2">    
    <description>The PSR2 coding standard.</description>    
    <rule ref="PSR2"/>     
    <file>app/</file>     
    <exclude-pattern>vendor</exclude-pattern>    
    <exclude-pattern>resources</exclude-pattern>    
    <exclude-pattern>database/</exclude-pattern>    
    <exclude-pattern>storage/</exclude-pattern>    
    <exclude-pattern>node_modules/</exclude-pattern>
    <exclude-pattern>public</exclude-pattern>
    </ruleset>

Now we can check our all app/ directory code by just a simple command
    
    ./vendor/bin/phpcs
    
    
Use this comment for automatically fix simple those error
    
    ./vendor/bin/phpcbf

Every time we write any new code we have to run this command again and again. We can make it more simpler like we could add a rule on git pre hook to run this before any new commit.

2.PHPMD

Install by composer

    composer require --dev phpmd/phpmd

Run PPHMD on terminal

Command Analysis:

- Phpmd location

        vendor/bin/phpmd
    
- Analysable code directory

        vendor/bin/phpmd app
    
- Output format(text is also fine)
    
        vendor/bin/phpmd html
    
- Rule to analysis code

        vendor/bin/phpmd cleancode,codesize,controversial,design,naming,unusedcode 
    
- Save output on phpmd.html file

        vendor/bin/phpmd > phpmd.html

We can save all rules on a xml file. See the file: phpmd.xml


Now we can run PHPMD on terminal like bellow

vendor/bin/phpmd app html phpmd.xml > phpmd.html

3.PHAN
install by composer 

    composer require --dev "phan/phan:2.x"
  
The Phan is depend on php-ast so before run project install php-ast.
Please read this documentation to install php-ast
https://github.com/nikic/php-ast
  
Before run PHAN we need to create a PHAN configure file. 
Create a .phan directory on your project root directory and inside directory make a config.xml file.
Give a look on config file .phan/config.php
  
Now run phan on your project

    ./vendor/bin/phan


